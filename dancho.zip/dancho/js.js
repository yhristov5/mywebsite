﻿function smile1() {
    var canvas = document.getElementById('player1Smile');
    var context = canvas.getContext('2d');
    context.fillStyle = 'LawnGreen';
    context.strokeStyle = 'black';
    context.lineWidth = 5;
    context.beginPath();
    context.arc(160, 120, 100, 0, 2 * Math.PI);
    context.fill();
    context.stroke();
    context.closePath();
    context.fillStyle = 'cyan';
    context.beginPath();
    context.arc(135, 87, 15, 0, 2 * Math.PI);
    context.fill();
    context.stroke();
    context.closePath();
    context.beginPath();
    context.arc(185, 87, 15, 0, 2 * Math.PI);
    context.fill();
    context.stroke();
    context.closePath();
    context.strokeStyle = 'magenta';
    context.lineWidth = 5;
    context.beginPath();
    context.arc(160, 120, 75, 0, -1 * Math.PI);
    context.stroke();
    context.closePath();
}
function smile2() {
    var canvas = document.getElementById('player2Smile');
    var context = canvas.getContext('2d');
    context.fillStyle = 'LawnGreen';
    context.strokeStyle = 'black';
    context.lineWidth = 5;
    context.beginPath();
    context.arc(160, 120, 100, 0, 2 * Math.PI);
    context.fill();
    context.stroke();
    context.closePath();
    context.fillStyle = 'cyan';
    context.beginPath();
    context.arc(135, 87, 15, 0, 2 * Math.PI);
    context.fill();
    context.stroke();
    context.closePath();
    context.beginPath();
    context.arc(185, 87, 15, 0, 2 * Math.PI);
    context.fill();
    context.stroke();
    context.closePath();
    context.strokeStyle = 'magenta';
    context.lineWidth = 5;
    context.beginPath();
    context.arc(160, 120, 75, 0, -1 * Math.PI);
    context.stroke();
    context.closePath();
}
var t = 'X';

var tictactoe = [
    [0, 0, 0],
    [0, 0, 0],
    [0, 0, 0]
];
var sp = document.querySelectorAll('.tictactoe span');
function win(p) {
    if (p) {
        var inp = document.getElementById('player1');
        alert(inp.value.trim() + " wins!");
        smile1();
    }
    else {
        var inp = document.getElementById('player2');
        alert(inp.value.trim() + " wins!");
        smile2();
    }
    for (var i = 0; i < sp.length; i++) {
        (function (index) {
            sp[index].replaceWith(sp[index].cloneNode(true));
        })(i);
    }
}
function checkWinner(id, p) {
    var f = id.charAt(0) - 1;
    var s = id.charAt(1) - 1;
    if (p) {
        tictactoe[f][s] = 1;
    }
    else {
        tictactoe[f][s] = 2;
    }
    for (var i = 0; i < 3; i++) {
        if (tictactoe[i][0] === tictactoe[i][1] && tictactoe[i][0] === tictactoe[i][2] && tictactoe[i][0] != 0) {
            win(p);
        }
    }
    if (tictactoe[0][0] === tictactoe[1][1] && tictactoe[2][2] === tictactoe[0][0] && tictactoe[0][0] != 0) {
        win(p);
    }
    if (tictactoe[2][0] === tictactoe[1][1] && tictactoe[2][0] === tictactoe[0][2] && tictactoe[2][0] != 0) {
        win(p);
    }
}

for (var i = 0; i < sp.length; i++) {
    (function (index) {
        sp[index].addEventListener("click", function () {
            if (sp[index].textContent.length > 0) return;
            sp[index].textContent = t;
            if (t == 'X') {
                t = 'O';
                checkWinner(sp[index].id, true);
            }
            else {
                t = 'X'
                checkWinner(sp[index].id, false);
            }
        });
    })(i);
};

document.body.onkeydown = function (e) {
    if (String.fromCharCode(e.keyCode) === 'R') {
        var canvas = document.getElementById('player1Smile');
        var context = canvas.getContext('2d');
        context.clearRect(0, 0, canvas.width, canvas.height);
        canvas = document.getElementById('player2Smile');
        context = canvas.getContext('2d');
        context.clearRect(0, 0, canvas.width, canvas.height);
        var sp = document.querySelectorAll('.tictactoe span');
        for (var i = 0; i < sp.length; i++) {
            (function (index) {
                sp[index].innerHTML = "";
                sp[index].addEventListener("click", function () {
                    if (sp[index].textContent.length > 0) return;
                    sp[index].textContent = t;
                    if (t == 'X') {
                        t = 'O';
                        checkWinner(sp[index].id, true);
                    }
                    else {
                        t = 'X'
                        checkWinner(sp[index].id, false);
                    }
                });
            })(i);
        };
    }
};